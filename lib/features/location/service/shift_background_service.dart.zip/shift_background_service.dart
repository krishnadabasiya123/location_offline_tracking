// ignore_for_file: unreachable_from_main

import 'dart:async';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:geolocator/geolocator.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:omkar_sale/commons/repositories/setting_local_repositories.dart';
import 'package:omkar_sale/core/api/api_end_points.dart';
import 'package:omkar_sale/features/location/model/location_point.dart';
import 'package:omkar_sale/features/location/repository/location_repository.dart';
import 'package:path_provider/path_provider.dart';

// ---------------------------------------------------------------------------
// BACKGROUND SERVICE ENTRY POINT
// Must be a top-level function annotated with @pragma('vm:entry-point').
// Runs in a separate Dart isolate — keeps location tracking alive
// even when the main Flutter engine is killed by the OS.
// ---------------------------------------------------------------------------

@pragma('vm:entry-point')
Future<void> onShiftServiceStart(ServiceInstance service) async {
  // 1. Initialize PathProvider and Hive in this isolate
  try {
    final dir = await getApplicationDocumentsDirectory();
    Hive.init(dir.path);
  } on Exception catch (e) {
    print('❌ BG TRACKER: Failed to initialize Hive path: $e');
  }

  String? token;
  var interval = 15;
  var isTrackingInitialized = false;

  StreamSubscription<Position>? positionSubscription;
  Timer? heartbeatTimer;
  Timer? recoveryTimer;
  Timer? watchdogTimer;

  var isSyncing = false;

  double? lastSavedLat;
  double? lastSavedLon;
  DateTime? lastSavedTimestamp;
  DateTime? lastSavedWallTime;
  DateTime? lastSyncTime;

  var isActive = false;

  // --- HIVE DIRECT OPERATIONS ---
  Future<Box<LocationPoint>> openLocationBox() async {
    if (!Hive.isAdapterRegistered(LocationPointAdapter().typeId)) {
      Hive.registerAdapter(LocationPointAdapter());
    }
    if (Hive.isBoxOpen(LocationRepository.kHiveBoxName)) {
      return Hive.box<LocationPoint>(LocationRepository.kHiveBoxName);
    }
    return Hive.openBox<LocationPoint>(LocationRepository.kHiveBoxName);
  }

  Future<void> saveLocationPoint(LocationPoint point) async {
    try {
      final box = await openLocationBox();
      await box.add(point);
      // Update liveness key so workmanager watchdog (separate isolate)
      // correctly detects bg isolate is alive and skips needless restart.
      try {
        final prefs = Hive.isBoxOpen('app_preferences') ? Hive.box<dynamic>('app_preferences') : await Hive.openBox<dynamic>('app_preferences');
        await prefs.put(
          'lastFixEpochMs',
          DateTime.now().millisecondsSinceEpoch,
        );
      } on Exception catch (_) {}
      print('✅ BG SAVED: ${point.latitude}, ${point.longitude}');
    } on Exception catch (e) {
      print('❌ BG SAVE ERROR: $e');
    }
  }

  Future<bool> syncLocationsDirect(
    String authToken,
    Box<LocationPoint> box, {
    int chunkSize = 500,
  }) async {
    final allKeys = box.keys.toList();
    final allPoints = box.values.toList();

    if (allPoints.isEmpty) {
      print('✅ BG REPO: Nothing to sync.');
      return true;
    }

    final dio = Dio(
      BaseOptions(
        connectTimeout: const Duration(seconds: 30),
        sendTimeout: const Duration(seconds: 30),
        receiveTimeout: const Duration(seconds: 30),
      ),
    );
    try {
      print(
        '🚀 BG REPO: Syncing ${allPoints.length} points in chunks of $chunkSize...',
      );

      for (var i = 0; i < allPoints.length; i += chunkSize) {
        final end = (i + chunkSize < allPoints.length) ? i + chunkSize : allPoints.length;
        final chunkPoints = allPoints.sublist(i, end);
        final chunkKeys = allKeys.sublist(i, end);

        final body = <String, String>{};
        var apiIndex = 0;
        for (final point in chunkPoints) {
          final lat = point.latitude.toString();
          final lon = point.longitude.toString();
          if (lat.isNotEmpty && lon.isNotEmpty) {
            body['location[$apiIndex][latitude]'] = lat;
            body['location[$apiIndex][longitude]'] = lon;
            apiIndex++;
          }
        }

        if (body.isEmpty) continue;

        final formData = FormData.fromMap(body, ListFormat.multiCompatible);

        final response = await dio.post<Map<String, dynamic>>(
          updateUserLocationUrl,
          data: formData,
          options: Options(
            headers: {
              'Authorization': 'Bearer $authToken',
            },
          ),
        );

        if (response.data != null && response.data!['error'] as bool) {
          throw Exception(response.data!['message'] as String);
        }

        await box.deleteAll(chunkKeys);
        print('✅ BG REPO: Batch synced successfully.');
      }
      return true;
    } on Exception catch (e) {
      print('❌ BG SYNC ERROR: $e');
      return false;
    }
  }

  Future<void> syncToServer() async {
    if (isSyncing || token == null) return;
    isSyncing = true;
    try {
      final box = await openLocationBox();
      final success = await syncLocationsDirect(token!, box);
      if (success) {
        lastSyncTime = DateTime.now();
      }
    } on Exception catch (e) {
      print('❌ BG syncToServer error: $e');
    } finally {
      isSyncing = false;
    }
  }

  // --- STREAM MANAGEMENT ---
  Future<void> startStream() async {
    await positionSubscription?.cancel();
    positionSubscription = null;

    late LocationSettings locationSettings;

    if (Platform.isAndroid) {
      locationSettings = AndroidSettings(
        accuracy: LocationAccuracy.bestForNavigation,
        intervalDuration: const Duration(seconds: 5),
        distanceFilter: 5,
        foregroundNotificationConfig: const ForegroundNotificationConfig(
          notificationText: '',
          notificationTitle: 'Location Service',
          notificationChannelName: 'Location Tracking',
          enableWakeLock: true,
          notificationIcon: AndroidResource(name: 'ic_transparent'),
        ),
      );
    } else if (Platform.isIOS || Platform.isMacOS) {
      locationSettings = AppleSettings(
        accuracy: LocationAccuracy.bestForNavigation,
        activityType: ActivityType.automotiveNavigation,
        showBackgroundLocationIndicator: true,
      );
    } else {
      locationSettings = const LocationSettings(
        accuracy: LocationAccuracy.bestForNavigation,
      );
    }

    positionSubscription =
        Geolocator.getPositionStream(
          locationSettings: locationSettings,
        ).listen(
          (position) async {
            print('BG _processLocation: ${position.toJson()}');

            // GATE 1: ACCURACY (<=50m)
            if (position.accuracy > 50) return;

            // GATE 2: STALE DATA (<=60s)
            final ageSeconds = DateTime.now().difference(position.timestamp).inSeconds.abs();
            if (ageSeconds > 60) return;

            // GATE 2.5: INTERNAL SESSION TIMEOUT (>= 5 min silence)
            if (lastSavedWallTime != null) {
              final silenceSeconds = DateTime.now().difference(lastSavedWallTime!).inSeconds;
              if (silenceSeconds >= 300) {
                lastSavedLat = null;
                lastSavedLon = null;
                lastSavedTimestamp = null;
                lastSavedWallTime = null;
              }
            }

            // GATE 3: SPEED (<=70 m/s)
            if (position.speed > 70) return;

            // GATE 4: JITTER (<3m, speed<5m/s)
            if (lastSavedLat != null && lastSavedLon != null && lastSavedTimestamp != null) {
              final timeDiffSeconds = position.timestamp.difference(lastSavedTimestamp!).inSeconds.abs();
              if (timeDiffSeconds < 1) return;

              if (position.speed < 5) {
                final distance = Geolocator.distanceBetween(
                  lastSavedLat!,
                  lastSavedLon!,
                  position.latitude,
                  position.longitude,
                );
                if (distance < 3) return;
              }
            }

            // ACCEPTED — SAVE
            lastSavedLat = position.latitude;
            lastSavedLon = position.longitude;
            lastSavedTimestamp = position.timestamp;
            lastSavedWallTime = DateTime.now();

            final point = LocationPoint(
              latitude: position.latitude,
              longitude: position.longitude,
              speed: position.speed,
              timestamp: position.timestamp,
            );

            await saveLocationPoint(point);

            // Check sync triggers immediately
            final box = await openLocationBox();
            final count = box.length;
            if (count >= 500) {
              await syncToServer();
            } else {
              final elapsed = DateTime.now().difference(
                lastSyncTime ?? DateTime.now().subtract(const Duration(hours: 1)),
              );
              if (elapsed.inSeconds >= (interval * 60)) {
                await syncToServer();
              }
            }
          },
          onError: (Object? error) {
            print('❌ BG TRACKER: Stream error: $error');

            // Start recovery poller if it's not already running
            recoveryTimer ??= Timer.periodic(const Duration(seconds: 15), (
              _,
            ) async {
              if (!isActive) {
                recoveryTimer?.cancel();
                recoveryTimer = null;
                return;
              }

              final permission = await Geolocator.checkPermission();
              final hasPermission = permission == LocationPermission.always || permission == LocationPermission.whileInUse;
              if (!hasPermission) return;

              final serviceEnabled = await Geolocator.isLocationServiceEnabled();
              if (!serviceEnabled) return;

              recoveryTimer?.cancel();
              recoveryTimer = null;

              lastSavedLat = null;
              lastSavedLon = null;
              lastSavedTimestamp = null;
              lastSavedWallTime = null;

              await startStream();
            });
          },
        );
  }

  Future<void> checkSyncDue() async {
    if (!isActive || isSyncing || token == null) return;

    final elapsed = DateTime.now().difference(
      lastSyncTime ?? DateTime.now().subtract(const Duration(hours: 1)),
    );

    if (elapsed.inSeconds < (interval * 60)) return;

    final box = await openLocationBox();
    if (box.length > 0) {
      await syncToServer();
      return;
    }

    // Stationary recovery - get a fresh GPS fix
    try {
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.bestForNavigation,
        ),
      );

      if (position.accuracy <= 50) {
        // Run process gates manually on heartbeat fix
        if (position.speed <= 70) {
          lastSavedLat = position.latitude;
          lastSavedLon = position.longitude;
          lastSavedTimestamp = position.timestamp;
          lastSavedWallTime = DateTime.now();

          final point = LocationPoint(
            latitude: position.latitude,
            longitude: position.longitude,
            speed: position.speed,
            timestamp: position.timestamp,
          );

          await saveLocationPoint(point);
          await syncToServer();
        }
      }
    } on Exception catch (_) {}
  }

  Future<void> startTracking() async {
    if (isTrackingInitialized) return;
    isTrackingInitialized = true;
    isActive = true;
    lastSavedLat = null;
    lastSavedLon = null;
    lastSavedTimestamp = null;
    lastSavedWallTime = null;
    lastSyncTime = DateTime.now();

    await startStream();

    heartbeatTimer = Timer.periodic(
      const Duration(seconds: 60),
      (_) => checkSyncDue(),
    );
  }

  // --- CLEANUP ---
  Future<void> stopTracking() async {
    isActive = false;
    watchdogTimer?.cancel();
    heartbeatTimer?.cancel();
    recoveryTimer?.cancel();
    await positionSubscription?.cancel();

    // Final sync attempt
    if (token != null) {
      try {
        final box = await openLocationBox();
        await syncLocationsDirect(token!, box);
        await box.close();
      } on Exception catch (_) {}
    }

    // Set isActive = false in shift_config
    try {
      final configBox = await Hive.openBox<dynamic>('shift_config');
      await configBox.put('isActive', false);
      await configBox.close();
    } on Exception catch (_) {}

    service.stopSelf();
  }

  // --- TIMEOUT AND EVENTS ---
  final completer = Completer<void>();

  service.on('init').listen((event) async {
    if (event == null) return;
    token = event['token'] as String?;
    interval = event['interval'] as int? ?? 15;

    // Save to Hive config for WatchdogReceiver survival
    if (token != null) {
      try {
        final configBox = await Hive.openBox<dynamic>('shift_config');
        await configBox.put('token', token);
        await configBox.put('interval', interval);
        await configBox.put('isActive', true);
        await configBox.close();
      } on Exception catch (_) {}
    }

    if (!completer.isCompleted) completer.complete();

    if (isTrackingInitialized) {
      // Re-configure heartbeat timer
      heartbeatTimer?.cancel();
      heartbeatTimer = Timer.periodic(
        const Duration(seconds: 60),
        (_) => checkSyncDue(),
      );
    } else {
      startTracking();
    }
  });

  service.on('stopService').listen((_) async {
    await stopTracking();
  });

  if (service is AndroidServiceInstance) {
    watchdogTimer = Timer.periodic(const Duration(seconds: 3), (_) async {
      if (await service.isForegroundService()) {
        service.setForegroundNotificationInfo(
          title: 'Omkar - Shift Active',
          content: 'Tracking your shift location',
        );
      }
    });
  }

  // Wait 5s for the main app to send the init config
  Future.delayed(const Duration(seconds: 5), () {
    if (!completer.isCompleted) {
      completer.complete();
    }
  });

  await completer.future;

  // Fallback: If init was not received (WatchdogReceiver restart), load config from Hive
  if (token == null) {
    try {
      final configBox = await Hive.openBox<dynamic>('shift_config');
      final savedActive = configBox.get('isActive') as bool? ?? false;
      final savedToken = configBox.get('token') as String?;
      final savedInterval = configBox.get('interval') as int? ?? 15;
      await configBox.close();

      if (savedActive && savedToken != null && savedToken.isNotEmpty) {
        token = savedToken;
        interval = savedInterval;
        await startTracking();
      } else {
        await stopTracking();
      }
    } on Exception catch (_) {
      await stopTracking();
    }
  }
}

// ---------------------------------------------------------------------------
// PUBLIC API
// ---------------------------------------------------------------------------

/// Call once at app startup from main() — BEFORE runApp.
Future<void> configureShiftService() async {
  await FlutterBackgroundService().configure(
    androidConfiguration: AndroidConfiguration(
      onStart: onShiftServiceStart,
      autoStart: false,
      isForegroundMode: true,
      initialNotificationTitle: 'Omkar - Shift Active',
      initialNotificationContent: 'Tracking your shift location',
      foregroundServiceNotificationId: 1001,
      foregroundServiceTypes: [AndroidForegroundType.dataSync],
    ),
    iosConfiguration: IosConfiguration(autoStart: false),
  );
}

/// Start the foreground notification service on clock-in.
Future<void> startShiftService(String token, int interval) async {
  // Save shift config for watchdog restart survival
  await SettingLocalRepository.instance.saveShiftConfig(
    token: token,
    interval: interval,
    isActive: true,
  );

  final service = FlutterBackgroundService();
  if (await service.isRunning()) {
    service.invoke('init', {'token': token, 'interval': interval});
    return;
  }

  await service.startService();
  // Wait a small moment for service isolate initialization, then invoke init
  await Future<void>.delayed(const Duration(milliseconds: 500));
  service.invoke('init', {'token': token, 'interval': interval});
}

/// Stop the foreground notification service on clock-out.
void stopShiftService() {
  FlutterBackgroundService().invoke('stopService');
}
